<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    public function login(Request $request){
      $input = $request->all();
      $this->validate($request,[
        'username'=>'required',
        'password'=>'required',
      ]);

      if(auth()->attempt(array('username'=>$input['username'] , 'password'=>$input['password'],'statut'=>'activer'))){


        if(auth()->user()){
          return redirect()->route('home');
        }



          toast("Aucun co","warning");
          return redirect()->route('login');
      }
      else{
          toast("Aucun compte","warning");
          return redirect()->route('login');

      }

    }
}
